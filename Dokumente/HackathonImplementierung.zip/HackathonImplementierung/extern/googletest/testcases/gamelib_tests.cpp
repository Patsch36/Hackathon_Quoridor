#include "gtest/gtest.h"
#include "../../../GameLib/GameField.h"


TEST(Dummy, dummy)
{
    GameField field;
}
