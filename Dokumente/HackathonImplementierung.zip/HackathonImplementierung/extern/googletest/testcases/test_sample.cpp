//
// Created by danie on 25.06.2020.
//

#include "gtest/gtest.h"

TEST(SquareRootTest, TestcaseName) {
    ASSERT_EQ(6*6, 36);
    //EXPECT_EQ(18.0, 18);
}
