#include <iostream>
#include "GameLib/GameField.h"

int main()
{
    std::cout << "Good luck, have fun!" << std::endl;
    GameField field;
    std::cout << field.toString() << std::endl;
    return 0;
}
